# Belly Button Biodiversity

In this module, students will build a dynamic dashboard using JavaScript, as well as Plotly and D3 libraries. They will deploy the dashboard to GitHub Pages.
