Plotly.newPlot("plotArea", [{x: [1, 2, 3], y: [10, 20, 30]}]);
