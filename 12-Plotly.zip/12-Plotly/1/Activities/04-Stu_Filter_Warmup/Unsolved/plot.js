// Filter the top 15 cities with a population increase greater than 15,000
//  and then graph each city on the x-axis and the respective population on the y-axis.

// 1. Create a custom filtering function that returns
//  the cities with a population increase greater than 15,000.
// {
//     "Rank": 1,
//     "City": "San Antonio ",
//     "State": "Texas",
//     "Increase_from_2016": "24208",
//     "population": "1511946"
//   },

function population(city){
    return city.Increase_from_2016 > 15000;
}

// 2. Use filter() to pass the function as its argument
var large_cities = top15Cities.filter(population);
// Check to make sure you filtered your cities correctly
// HINT: console.log() is your friend.

console.log(large_cities);

// 3. Use the map method with the arrow function to return all the filtered cities' names.

var cityNames = large_cities.map(d=>d.City);

//  Check your filtered cities
console.log(cityNames);


// 4. Use the map method with the arrow function to return all the filtered cities' populations.
var cityPopulation = large_cities.map(d=>+d.population);


//  Check the populations of your filtered cities
console.log(cityPopulation);

// 5. Create your trace.
var data = [
    {
        x: cityNames,
        y: cityPopulation,
        type: "bar"
    }
]

// 6. Create the data array for our plot


// 7. Define our plot layout
Plotly.newPlot("bar-plot", data);

// 8. Plot the chart to a div tag with id "bar-plot"
