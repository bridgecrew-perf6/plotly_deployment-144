// Filter the data for movies with an IMDb rating greater than 8.9
//  and then graph each title on the x-axis and the respective metascore on the y-axis.

// 1. Use the filter method to create a custom filtering function
//  that returns the movies with a rating greater than 8.9

function topmovies(stella){
    return stella.imdbRating>8.9;
}


console.log(topMovies);

// 2. Use filter() to pass the function as its argument


var filteredData = topMovies.filter(topmovies);

// var filteredData = topMovies.filter(function (movies){
//     return movies.imdbRating>8.9;
// });

// var filteredData = topMovies.filter(movies => movies.imdbRating>8.9);

// var filteredData = topMovies.filter(function (movies){
//     return movies.imdbRating>8.9;
// });
//  {
//     title: "The Shawshank Redemption",
//     year: 1994,
//     imdbRating: 9.3,
//     metascore: 80
//   },
  
// var filteredData = topMovies.filter(movies => movies.imdbRating>8.9);
console.log(filteredData);

//  Check to make sure your are filtering your movies.

// 3. Use the map method with the arrow function to return all the filtered movie titles.
function titles(movies){
    return movies.title;
}

var movieTitles = topMovies.map(titles);
// var movieTitles = topMovies.map(movie=>movie.title);
console.log(movieTitles);

//  Check your filtered movie titles.

// 4. Use the map method with the arrow function to return all the filtered movie metascores.
var movieScores = topMovies.map(movie=>movie.imdbRating);
console.log(movieScores);


//  Check your filtered movie metascores.

// 5. Create your trace.
var data = [
    {
        x: movieTitles,
        y: movieScores,
        type: "bar"
        
    }
]

// 6. Create the data array for our plot
Plotly.newPlot("bar-plot", data)

// 7. Define our plot layout


// 8. Plot the chart to a div tag with id "bar-plot"
