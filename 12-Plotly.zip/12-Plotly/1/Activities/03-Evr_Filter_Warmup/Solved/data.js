var topMovies = [
  {
  title: "The Shawshank Redemption",
  year: 1994,
  imdbRating: 9.3,
  metascore: 80
},
{
  title: "The Godfather",
  year: 1972,
  imdbRating: 9.2,
  metascore: 100
},
{
  title: "The Dark Knight",
  year: 2008,
  imdbRating: 9.0,
  metascore: 84
},
{
  title: "The Godfather: Part II",
  year: 1974,
  imdbRating: 9.0,
  metascore: 90
},
{
  title: "The Lord of the Rings: The Return of the King",
  year: 2003,
  imdbRating: 8.9,
  metascore: 94
},
{
  title: "Pulp Fiction",
  year: 1994,
  imdbRating: 8.9,
  metascore: 94
},
{
  title: "Schindeler's List",
  year: 1993,
  imdbRating: 8.9,
  metascore: 93
},
{
  title: "12 Angry Men",
  year: 1957,
  imdbRating: 8.9,
  metascore: 96
},
{
  title: "Fight Club",
  year: 1999,
  imdbRating: 8.8,
  metascore: 66
},
{
  title: "The Lord of the Rings: The Fellowship of the Ring",
  year: 2001,
  imdbRating: 8.8,
  metascore: 92
}
];
