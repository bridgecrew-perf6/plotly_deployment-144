// Sort the data by Greek search results
var greekGods = data.sort((a, b) => b.romanSearchResults-a.romanSearchResults).slice(0, 10).reverse();
// Slice the first 10 objects for plotting
console.log(greekGods);
// Reverse the array to accommodate Plotly's defaults

// Trace1 for the Greek Data
var Trace1 = {
    y: greekGods.map(d=>d.greekName),
    x: greekGods.map(d=>d.greekSearchResults),
    text: greekGods.map(d=>d.pair),
    name:"Greek",
    type:"bar",
    orientation: "h"
}
var Trace2 = {
    y: greekGods.map(d=>d.greekName),
    x: greekGods.map(d=>d.romanSearchResults),
    text: greekGods.map(d=>d.romanName),
    name:"Roman",
    type:"bar",
    orientation: "h"
}
// data
layout = {
    Title: "Greek/Roman Gods",
    margin: {
        l:100,
        r:100,
    }
}
// Apply the group bar mode to the layout

// Render the plot to the div tag with id "plot"
Plotly.newPlot("plot", [Trace1, Trace2], layout)