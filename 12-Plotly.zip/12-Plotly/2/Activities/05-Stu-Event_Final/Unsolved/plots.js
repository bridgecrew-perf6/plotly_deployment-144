// Create an array of each country's numbers
var us = Object.values(data.us);
var uk = Object.values(data.uk);
var canada = Object.values(data.canada);

console.log(us);

// Create an array of music provider labels
var providers = Object.keys(data.uk);
console.log(providers);


// Display the default plot
Plotly.newPlot("pie", [{
  labels: providers,
  values: us,
  type: "pie"
}]);

// On change to the DOM, call getData()

d3.selectAll("#country").on("change", dosomething);

function dosomething(){
  var country = d3.select("#country");
  var c = country.property("value");
  if(c=="us") v = us;
  else if(c=="uk") v = uk;
  else v = canada;
  console.log(v);
  Plotly.restyle("pie", "values", [v]);
}

// Function called by DOM changes

  // Assign the value of the dropdown menu option to a variable

  // Initialize an empty array for the country's data


// Update the restyled plot's values
