var data = {
    us: {
        Spotify: 19,
        Soundcloud: 5,
        Pandora: 8,
        Itunes: 30
    },

    uk: {
        Spotify: 10,
        Soundcloud: 2,
        Pandora: 22,
        Itunes: 37
    },

    canada: {
        Spotify: 14,
        Soundcloud: 2,
        Pandora: 5,
        Itunes: 15
    }
};
