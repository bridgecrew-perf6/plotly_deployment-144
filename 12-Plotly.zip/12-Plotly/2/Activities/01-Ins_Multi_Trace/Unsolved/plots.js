function random_num(n) {
    var rand = [];
    for (var i = 0; i<n; i++){
        rand.push(Math.floor(Math.random()*10)+1);
    }
    return rand;
}
var x = [1, 2, 3, 4, 5];
var y1 = random_num(5);
var y2 = random_num(5);
console.log(x);
console.log(y1);
console.log(y2);

var trace1 = {
    x: x,
    y: y1,
    type:"bar",
    name:"Cars",
}
var trace2 = {
    x: x,
    y: y2,
    name:"Busses",
    type:"bar",
}

Plotly.newPlot("plot", [trace1, trace2])
Plotly.newPlot("plot2", [trace2])
