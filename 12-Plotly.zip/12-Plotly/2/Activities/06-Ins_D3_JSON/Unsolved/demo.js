// const url = "https://api.spacexdata.com/v2/launchpads";
// d3.json(url).then(function(data){
//     console.log(data);
// });

// const url = "https://api.spacexdata.com/v2/launchpads";
var apiKey = "YOUR KEY HERE";
var city = "San Francisco";
const url = `https://api.openweathermap.org/data/2.5/forecast?q=${city}&appid=${apiKey}&units=imperial`
d3.json(url).then(function(d){
    var data = d.list;
    var dt_txt = data.map(d=>d.dt_txt);
    var temp = data.map(d=>d.main.temp);
    Plotly.newPlot("plot", [
        {
            x:dt_txt,
            y:temp
        }
    ])
    console.log(temp);
    console.log(dt_txt);
    console.log(data);
});

