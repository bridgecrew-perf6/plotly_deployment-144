function init() {
    data = [{
        x: [1, 2, 3, 4, 5],
        y: [1, 2, 4, 8, 16]
    }];
    Plotly.newPlot("plot", data);
}
d3.select("#selDataset").on("change", dosomething);

function dosomething() {
    var sel = d3.selectAll("#selDataset");
    var val = sel.property("value");

    switch(val){
        case "dataset2":
            x = [1, 2, 3, 4, 5];
            y = [2, 5, 2, 3, 22];
            var type = "line";
        break;
        case "dataset1":
            x = [1, 2, 3, 4, 5];
            y = [1, 2, 4, 8, 16];
            var type = "bar";
        break;
    }
    Plotly.restyle("plot", "x", [x]);
    Plotly.restyle("plot", "y", [y]);
    Plotly.restyle("plot", "type", type);
    // d3.select("#plot").text("");
    console.log(val);
}


init();