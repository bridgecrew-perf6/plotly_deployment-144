// @ADD YOUR CODE HERE
function update_page(){
    var pickme = d3.select("#pickme");
    var a = pickme.property("value");
    var menu = d3.select("#menu");
    menu.text(a);
    
    // console.log(a);
}

d3.select("#pickme").on("change", update_page)